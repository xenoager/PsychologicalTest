import React, { useEffect, useMemo, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import Progress from "../components/Progress.jsx";
import { sendEvent } from "../lib/ga.js";
import { evaluateQuiz } from "../lib/engine.js";
import { assetUrl } from "../utils/asset.js";

export default function Quiz() {
  const { slug } = useParams();
  const nav = useNavigate();

  useEffect(() => {
    sendEvent("quiz_start", { quiz_slug: slug });
  }, [slug]);

  const [raw, setRaw] = useState(null);
  const [quiz, setQuiz] = useState(null); // normalized
  const [answers, setAnswers] = useState({});
  const [index, setIndex] = useState(0);
  const [showLastWarn, setShowLastWarn] = useState(false); // ⬅︎ 레이어 팝업 표시 상태
  useEffect(() => {
    // 팝업 표시 중에는 배경 스크롤 잠금
    if (showLastWarn) {
      const prev = document.body.style.overflow;
      document.body.style.overflow = "hidden";
      return () => {
        document.body.style.overflow = prev;
      };
    }
  }, [showLastWarn]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    let alive = true;
    async function load() {
      setLoading(true);
      setError(null);
      setQuiz(null);
      setRaw(null);
      setIndex(0);
      setAnswers({});

      const tryPaths = [
        assetUrl(`quizzes/${slug}.json`),
        assetUrl(`quizzes/${(slug || "").replace(/-/g, "_")}.json`),
        assetUrl(`quizzes/${(slug || "").replace(/_/g, "-")}.json`),
      ];

      let data = null;
      let lastErr = null;
      for (const p of tryPaths) {
        try {
          const res = await fetch(p, { cache: "no-store" });
          if (res.ok) {
            data = await res.json();
            break;
          }
          lastErr = new Error(`HTTP ${res.status} @ ${p}`);
        } catch (e) {
          lastErr = e;
        }
      }

      if (!alive) return;

      if (!data) {
        setError(lastErr || new Error("퀴즈 로드 실패"));
        setLoading(false);
        return;
      }

      setRaw(data);
      setQuiz(normalizeQuiz(data));
      setLoading(false);
    }
    load();
    return () => {
      alive = false;
    };
  }, [slug]);

  function normalizeQuiz(raw) {
    const list = Array.isArray(raw?.questions)
      ? raw.questions
      : Array.isArray(raw?.items)
      ? raw.items
      : [];
    const questions = list.map((q, idx) => {
      const id = q.id ?? `q${idx + 1}`;
      const title = q.title ?? q.question ?? q.text ?? `문항 ${idx + 1}`;
      const optsSrc = Array.isArray(q.options)
        ? q.options
        : Array.isArray(q.choices)
        ? q.choices
        : Array.isArray(q.answers)
        ? q.answers
        : [];
      const options = optsSrc.map((o, j) => ({
        id: o.id ?? o.value ?? String.fromCharCode(97 + j),
        label: o.label ?? o.text ?? o.title ?? o.content ?? o.name ?? "",
        score: o.score ?? o.points,
        mbti: o.mbti ?? o.code,
        axis: o.axis,
        choice: o.choice,
        score_map: o.score_map,
      }));

      // === 중요: 정답 인덱스/설명 등 원본 필드 보존 ===
      const correct_index =
        (typeof q.correct_index === "number" ? q.correct_index : null) ??
        (typeof q.correctIndex === "number" ? q.correctIndex : null) ??
        (typeof q.answer_index === "number" ? q.answer_index : null) ??
        (typeof q.answerIndex === "number" ? q.answerIndex : null);

      const explain = q.explain ?? q.explanation ?? q.reason ?? "";
      const image = q.image ?? q.img ?? null;

      return { id, title, options, correct_index, explain, image };
    });
    const scoring = raw?.scoring || { engine: raw?.engine || "mbti" };
    return { ...raw, questions, scoring };
  }

  const questions = quiz?.questions || [];
  const q = questions[index];
  const total = Math.max(1, questions.length);
  const progress = Math.round(((index + 1) / total) * 100);
  const hasOptions = Array.isArray(q?.options) && q.options.length > 0;
  const selected = q ? answers[q.id] : undefined;

  // src/pages/Quiz.jsx
  function choose(qid, oid) {
    // 1) 답안 상태 업데이트
    setAnswers((prev) => ({ ...prev, [qid]: oid }));

    // 2) 이벤트 로깅 (상태 업데이트와 별개로 안전하게 분리)
    try {
      sendEvent("quiz_answer", { quiz_slug: slug, qid, oid, index: index + 1 });
    } catch (e) {
      // no-op
    }

    // 3) (기존에 다음 문항으로 이동/점수 계산/네비게이션하는 코드가 있다면 그대로 유지)
  }

  function goNext() {
    if (index < questions.length - 1) {
      setIndex(index + 1);
      return;
    }
    // 마지막 문항이 선택되지 않았으면 레이어 팝업 표시 후 중단
    const lastQ = questions[questions.length - 1];
    if (!answers[lastQ.id]) {
      setShowLastWarn(true);
      return;
    }
    const scored = evaluateQuiz(quiz || raw, answers);
    const t = String(scored.type).toUpperCase();
    const results = Array.isArray((quiz || raw)?.results)
      ? (quiz || raw).results
      : typeof (quiz || raw)?.results === "object" && (quiz || raw)?.results
      ? Object.entries((quiz || raw).results).map(([id, obj]) => ({
          id,
          ...(obj || {}),
        }))
      : [];
    const result =
      results.find((r) => {
        const pool = [
          r.id,
          r.type,
          r.code,
          r.mbti,
          r.slug,
          r.key,
          r.value,
          r.tag,
          r.kind,
        ]
          .filter(Boolean)
          .map((x) => String(x).toUpperCase());
        const hit = pool.includes(t);
        const titleHit = String(r?.title || "")
          .toUpperCase()
          .includes(t);
        const listHit =
          Array.isArray(r?.types) &&
          r.types.map((x) => String(x).toUpperCase()).includes(t);
        return hit || titleHit || listHit;
      }) || null;
    try {
      sessionStorage.setItem(`answers:${slug}`, JSON.stringify(answers));
    } catch {}
    try {
      sendEvent("quiz_complete", { quiz_slug: slug, result_type: scored.type });
    } catch (e) {}
    nav(`/${slug}/result/${scored.type}`, {
      state: { result, scored, quiz: quiz || raw, answers },
    });
  }

  function goPrev() {
    if (index > 0) setIndex(index - 1);
  }

  // --- NEW: 메인 '마인드픽Q' 버튼 동작 (초기 홈: 전체 + 스크롤 최상단) ---------
  function goInitialHome() {
    try {
      sessionStorage.removeItem("ps:quiz-list:need");
      sessionStorage.setItem("last-cat:/", "전체");
      sessionStorage.setItem("ps:quiz-list:cat", "전체");
      sessionStorage.setItem("ps:quiz-list:q", "");
      sessionStorage.setItem("scroll-pos:/", "0");
      sessionStorage.setItem("scroll-pos-ts:/", String(Date.now()));
    } catch {}
    try {
      window.scrollTo(0, 0);
    } catch {}
    nav("/", { replace: true });
  }

  /* ===================== NEW: 홈으로(스마트) =====================
   * Quiz에서의 홈 이동은 기본적으로 pop 1단계(nav(-1)).
   * 불가(새로고침/딥링크 등) 시 Home 복원 신호 세팅 후 '/' replace.
   */
  function buildSearch(c, query) {
    const parts = [];
    if (c && c !== "전체") parts.push("cat=" + encodeURIComponent(c));
    if (query) parts.push("q=" + encodeURIComponent(query));
    return parts.join("&");
  }
  function prepareHomeResume() {
    try {
      const catWanted0 =
        sessionStorage.getItem("ps:quiz-list:cat") ||
        sessionStorage.getItem("last-cat:/") ||
        "전체";
      const qWanted0 = sessionStorage.getItem("ps:quiz-list:q") || "";

      const makeKey = (c, query) =>
        "/" + (buildSearch(c, query) ? "?" + buildSearch(c, query) : "");

      const candidates = [
        makeKey(catWanted0, qWanted0),
        makeKey(catWanted0, ""),
        "/",
      ];

      let bestKey = null;
      let bestTs = -1;
      for (const k of candidates) {
        const ts = Number(sessionStorage.getItem("scroll-pos-ts:" + k) || "0");
        if (!Number.isNaN(ts) && ts > bestTs) {
          bestTs = ts;
          bestKey = k;
        }
      }

      let resumeCat = catWanted0;
      let resumeQ = qWanted0;
      if (bestKey && bestKey !== "/") {
        const idx = bestKey.indexOf("?");
        if (idx >= 0) {
          const sp = new URLSearchParams(bestKey.slice(idx));
          resumeCat = sp.get("cat") || "전체";
          resumeQ = sp.get("q") || "";
        }
      }

      sessionStorage.setItem("ps:quiz-list:need", "1");
      sessionStorage.setItem("ps:quiz-list:cat", resumeCat);
      sessionStorage.setItem("ps:quiz-list:q", resumeQ);
    } catch {}
  }

  function goHomeSmart() {
    // 항상 복원 신호를 먼저 세팅 (뒤로가기 시나리오에서도 스크롤/카테고리 복원 보장)
    prepareHomeResume();
    try {
      const idx = window.history?.state?.idx;
      if (typeof idx === "number" && idx >= 1) {
        nav(-1);
        return;
      }
    } catch {}
    nav("/", { replace: true });
  }

  if (loading)
    return (
      <div className="wrap">
        <div className="card">
          <div
            className="header"
            style={{
              marginBottom: 14,
              paddingBottom: 10,
              borderBottom: "1px solid rgba(255,255,255,.12)",
            }}
          >
            <div
              className="logo"
              role="button"
              tabIndex={0}
              aria-label="마인드픽Q 홈"
              onClick={goInitialHome}
              onKeyDown={(e) => {
                if (e.key === "Enter" || e.key === " ") goInitialHome();
              }}
            >
              <b className="brand">마인드픽Q</b>
            </div>
          </div>
          <div>로딩 중…</div>
        </div>
      </div>
    );

  if (error) {
    const msg = (error?.message || "").toString();
    return (
      <div className="wrap">
        <div className="card" style={{ maxWidth: 880 }}>
          <div
            className="header"
            style={{
              marginBottom: 14,
              paddingBottom: 10,
              borderBottom: "1px solid rgba(255,255,255,.12)",
            }}
          >
            <div
              className="logo"
              role="button"
              tabIndex={0}
              aria-label="마인드픽Q 홈"
              onClick={goInitialHome}
              onKeyDown={(e) => {
                if (e.key === "Enter" || e.key === " ") goInitialHome();
              }}
            >
              <b className="brand">마인드픽Q</b>
            </div>
          </div>

          <div className="topbar" style={{ marginTop: 12 }}>
            <button className="btn ghost" onClick={goHomeSmart}>
              ← 홈으로
            </button>
          </div>

          <div className="kicker">로딩 오류</div>
          <div style={{ color: "#9fb6d1", marginBottom: 8 }}>
            퀴즈 파일을 불러오지 못했습니다.
          </div>
          <div style={{ fontSize: 12, color: "#7a90ad" }}>{msg}</div>
          <div className="hr" />
          <button className="btn" onClick={() => location.reload()}>
            다시 시도
          </button>
        </div>
      </div>
    );
  }

  if (!quiz)
    return (
      <div className="wrap">
        <div className="card">
          <div
            className="header"
            style={{
              marginBottom: 14,
              paddingBottom: 10,
              borderBottom: "1px solid rgba(255,255,255,.12)",
            }}
          >
            <div
              className="logo"
              role="button"
              tabIndex={0}
              aria-label="마인드픽Q 홈"
              onClick={goInitialHome}
              onKeyDown={(e) => {
                if (e.key === "Enter" || e.key === " ") goInitialHome();
              }}
            >
              <b className="brand">마인드픽Q</b>
            </div>
          </div>
          퀴즈를 찾을 수 없습니다.
        </div>
      </div>
    );

  return (
    <div className="wrap">
      <div className="card" style={{ width: "100%", maxWidth: 880 }}>
        {/* NEW: 메인 '마인드픽Q' 버튼을 홈으로 위쪽(최상단)에 배치 + 구분선/간격 추가 */}
        <div
          className="header"
          style={{
            marginBottom: 14,
            paddingBottom: 10,
            borderBottom: "1px solid rgba(255,255,255,.12)",
          }}
        >
          <div
            className="logo"
            role="button"
            tabIndex={0}
            aria-label="마인드픽Q 홈"
            onClick={goInitialHome}
            onKeyDown={(e) => {
              if (e.key === "Enter" || e.key === " ") goInitialHome();
            }}
          >
            <b className="brand">마인드픽Q</b>
          </div>
        </div>

        <div className="topbar" style={{ marginTop: 12 }}>
          <button className="btn ghost" onClick={goHomeSmart}>
            ← 홈으로
          </button>
        </div>

        <div className="kicker">{quiz.title}</div>
        <Progress value={progress} />
        <div
          style={{
            display: "flex",
            justifyContent: "space-between",
            marginTop: 6,
            fontSize: 12,
            color: "#8aa2c1",
          }}
        >
          <div>
            문항 {Math.min(index + 1, total)} / {total}
          </div>
          <div>{progress}%</div>
        </div>

        <div style={{ height: 12 }} />
        <div className="qtitle">
          {index + 1}. {q?.title || "문항"}
        </div>

        {hasOptions ? (
          <div className="options">
            {q.options.map((opt) => (
              <button
                key={opt.id}
                className={`opt ${selected === opt.id ? "selected" : ""}`}
                onClick={() => choose(q.id, opt.id)}
              >
                {opt.label || "선택지"}
              </button>
            ))}
          </div>
        ) : (
          <div
            className="card"
            style={{ background: "transparent", border: "1px dashed #263041" }}
          >
            보기(option)가 정의되어 있지 않아요.
            <small style={{ display: "block", marginTop: 6, color: "#9fb6d1" }}>
              JSON의 <code>questions[{index}].options</code> 또는{" "}
              <code>choices/answers</code>를 확인해 주세요.
            </small>
          </div>
        )}

        <div className="toolbar">
          <button className="btn" onClick={goPrev} disabled={index === 0}>
            이전
          </button>
          <div style={{ flex: 1 }} />
          <button
            className="btn primary"
            onClick={goNext}
            // 마지막 문항: 선택 없어도 버튼 클릭은 가능 → 레이어 팝업으로 안내
            disabled={index < total - 1 && !selected}
          >
            {index < total - 1 ? "다음" : "결과 보기"}
          </button>
        </div>
      </div>

      {/* ⬇︎ 레이어 팝업(모달) — UI 구조/스타일 유지용 카드 사용 */}
      {showLastWarn && (
        <div
          role="dialog"
          aria-modal="true"
          aria-label="안내"
          style={{
            position: "fixed",
            inset: 0,
            zIndex: 1000,
            background: "rgba(0,0,0,.5)",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            padding: 16,
          }}
          onClick={() => setShowLastWarn(false)}
        >
          <div
            className="card"
            style={{
              position: "relative",
              maxWidth: 420,
              width: "100%",
              padding: 20,
              borderRadius: 16,
              boxShadow: "0 12px 40px rgba(0,0,0,.3)",
              background: "var(--card-bg, #0f1220)",
              border: "1px solid rgba(255,255,255,.08)",
            }}
            onClick={(e) => e.stopPropagation()}
          >
            <div className="kicker">안내</div>
            <h3 className="title" style={{ marginTop: 6 }}>
              마지막 응답을 해주세요
            </h3>
            <p style={{ opacity: 0.8, marginTop: 8 }}>
              모든 문항에 응답해야 결과를 볼 수 있어요.
            </p>
            <div
              className="toolbar"
              style={{
                marginTop: 16,
                display: "flex",
                gap: 8,
                justifyContent: "flex-end",
              }}
            >
              <button className="btn" onClick={() => setShowLastWarn(false)}>
                확인
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

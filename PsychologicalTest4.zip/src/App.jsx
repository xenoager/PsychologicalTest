import { BrowserRouter, Routes, Route } from "react-router-dom";
import { useEffect } from "react";
import Home from "./pages/Home.jsx";
import Quiz from "./pages/Quiz.jsx";
import Result from "./pages/Result.jsx";
import "./styles.css";

/** 라우트 전역에서 스크롤을 저장/복원한다.
 * - Home(“/”)에서 상세로 이동하기 직전: 현재 scrollY 저장
 * - 다시 Home 진입 시: 저장된 scrollY로 복원
 * - history.scrollRestoration='manual'로 브라우저 기본 동작 차단
 * - 전역 클릭 리스너는 'a[href^="/"]'로 한정 (카테고리 버튼 등에 영향 없음)
 */
function ScrollKeeper() {
  const { useLocation } = require("react-router-dom");
  const location = useLocation();

  useEffect(() => {
    if ("scrollRestoration" in history) history.scrollRestoration = "manual";
  }, []);

  // 내부 링크 클릭 시(상세로 이동 직전) 스크롤 저장
  useEffect(() => {
    const handleClick = (e) => {
      const el = e.target && e.target.closest ? e.target.closest("a") : null;
      if (!el) return;
      const href = el.getAttribute("href") || "";
      // 내부 라우팅만 처리
      if (href.startsWith("/")) {
        sessionStorage.setItem(
          "ps:quiz-list:scroll",
          String(window.scrollY || 0)
        );
      }
    };
    // capture 단계에서 먼저 저장 (라우터 전환 전에)
    document.addEventListener("click", handleClick, true);
    return () => document.removeEventListener("click", handleClick, true);
  }, []);

  // 라우트 변화 시: Home이면 복원, 그 외에서는 현재 스크롤을 저장
  useEffect(() => {
    const isHome = location.pathname === "/";
    if (isHome) {
      const y = sessionStorage.getItem("ps:quiz-list:scroll");
      if (y) {
        // 페인트 이후 즉시 복원
        requestAnimationFrame(() => {
          window.scrollTo(0, parseInt(y, 10) || 0);
        });
      }
    } else {
      sessionStorage.setItem(
        "ps:quiz-list:scroll",
        String(window.scrollY || 0)
      );
    }
  }, [location]);

  return null;
}

export default function App() {
  return (
    <BrowserRouter>
      <ScrollKeeper />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/:slug" element={<Quiz />} />
        <Route path="/:slug/result/:type" element={<Result />} />
      </Routes>
    </BrowserRouter>
  );
}

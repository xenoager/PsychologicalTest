import React from 'react'
import { useNavigate } from 'react-router-dom'

export default function Card({ item }) {
  const nav = useNavigate()
  return (
    <div className="card" role="button" onClick={() => nav('/' + item.slug)}>
      <div className="thumb" style={{
        background: item.gradient || 'linear-gradient(120deg,#1f3b8a 0%,#2d4c98 35%,#3b5ea7 70%,#5c86a3 100%)'
      }}>
        <div className="label">{item.badge || 'TEST'}</div>
      </div>
      <div className="meta">
        <div className="title">{item.title}</div>
        <div className="sub">{item.subtitle}</div>
      </div>
      <div className="footer">
        <span className="badge">{item.category}</span>
        {item.author && <span className="badge">by {item.author}</span>}
        <div style={{flex:1}} />
        <button className="btn">시작</button>
      </div>
    </div>
  )
}
